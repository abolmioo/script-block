package com.abol.scriptblock;

import com.abol.scriptblock.ScriptPayloads.Mode;
import com.abol.scriptblock.ScriptPayloads.Settings;
import com.mojang.brigadier.ParseResults;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class ScriptBlockEntity extends BlockEntity {
    // saved
    private String script = "";
    private Settings settings = Settings.DEFAULT;
    private boolean loopActive = false;

    // runtime
    private List<String> lines = List.of();
    private int index, waitTicks, cooldown, executed, errors, firstErrorLine;
    private boolean running, lastPowered;
    @Nullable private UUID lastUser;

    public ScriptBlockEntity(BlockPos pos, BlockState state) {
        super(ScriptMod.SCRIPT_BLOCK_ENTITY, pos, state);
    }

    public String getScript() { return script; }
    public Settings getSettings() { return settings; }
    public boolean isRunning() { return running || loopActive; }

    public void applySettings(String script, Settings settings) {
        this.script = script;
        this.settings = settings;
        if (settings.mode() == Mode.IMPULSE || settings.redstone()) loopActive = false;
        markDirty();
    }

    /** Called by the Run button. */
    public void start(@Nullable ServerPlayerEntity user) {
        if (user != null) lastUser = user.getUuid();
        if (settings.mode() == Mode.REPEAT && !settings.redstone()) {
            loopActive = true;
            markDirty();
        }
        begin();
    }

    public void stop() {
        boolean was = isRunning();
        running = false;
        loopActive = false;
        markDirty();
        if (was) notifyUser(Text.literal("Script stopped").formatted(Formatting.RED));
    }

    private void begin() {
        lines = Arrays.asList(script.split("\\R", -1));
        index = 0;
        waitTicks = 0;
        executed = 0;
        errors = 0;
        firstErrorLine = -1;
        running = true;
    }

    public static void tick(World world, BlockPos pos, BlockState state, ScriptBlockEntity be) {
        if (!(world instanceof ServerWorld sw)) return;

        boolean powered = world.isReceivingRedstonePower(pos);
        boolean rising = powered && !be.lastPowered;
        be.lastPowered = powered;

        if (be.running) {
            be.process(sw);
            return;
        }

        Settings s = be.settings;
        if (s.mode() == Mode.IMPULSE) {
            if (s.redstone() && rising) be.begin();
        } else {
            boolean active = s.redstone() ? powered : be.loopActive;
            if (active) {
                if (be.cooldown > 0) be.cooldown--;
                else be.begin();
            }
        }
    }

    private void process(ServerWorld world) {
        if (waitTicks > 0) {
            waitTicks--;
            return;
        }
        MinecraftServer server = world.getServer();
        ServerCommandSource source = server.getCommandSource()
                .withWorld(world)
                .withPosition(Vec3d.ofCenter(pos))
                .withLevel(2)
                .withSilent();

        int budget = settings.linesPerTick();
        while (running && budget > 0) {
            if (index >= lines.size()) {
                finish();
                return;
            }
            int lineNo = index + 1;
            String line = lines.get(index++).trim();

            // comments & blank lines
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) continue;
            if (line.startsWith("/")) line = line.substring(1).trim();

            // placeholders
            line = line.replace("{x}", String.valueOf(pos.getX()))
                       .replace("{y}", String.valueOf(pos.getY()))
                       .replace("{z}", String.valueOf(pos.getZ()));

            String lower = line.toLowerCase(Locale.ROOT);
            if (lower.startsWith("wait ")) {
                waitTicks = parseWait(line.substring(5));
                return;
            }
            if (lower.equals("stop")) {
                finish();
                return;
            }

            try {
                ParseResults<ServerCommandSource> parsed = server.getCommandManager().getDispatcher().parse(line, source);
                if (parsed.getReader().canRead() || !parsed.getExceptions().isEmpty()) {
                    errors++;
                    if (firstErrorLine < 0) firstErrorLine = lineNo;
                } else {
                    server.getCommandManager().execute(parsed, line);
                    executed++;
                }
            } catch (Exception e) {
                errors++;
                if (firstErrorLine < 0) firstErrorLine = lineNo;
                ScriptMod.LOGGER.warn("Script Block error at line {}: {}", lineNo, e.getMessage());
            }
            budget--;
        }
    }

    private void finish() {
        running = false;
        cooldown = settings.repeatDelay();
        if (settings.showOutput() && settings.mode() == Mode.IMPULSE) {
            Text msg = errors == 0
                    ? Text.literal("Done! " + executed + " commands").formatted(Formatting.GREEN)
                    : Text.literal("Done: " + executed + " ok, " + errors + " errors (first at line " + firstErrorLine + ")").formatted(Formatting.GOLD);
            notifyUser(msg);
        }
    }

    private void notifyUser(Text msg) {
        if (lastUser == null || !(world instanceof ServerWorld sw)) return;
        ServerPlayerEntity p = sw.getServer().getPlayerManager().getPlayer(lastUser);
        if (p != null) p.sendMessage(msg, true);
    }

    private static int parseWait(String arg) {
        try {
            String a = arg.trim().toLowerCase(Locale.ROOT);
            int ticks;
            if (a.endsWith("s")) ticks = (int) (Double.parseDouble(a.substring(0, a.length() - 1)) * 20);
            else if (a.endsWith("t")) ticks = Integer.parseInt(a.substring(0, a.length() - 1));
            else ticks = Integer.parseInt(a);
            return MathHelper.clamp(ticks, 0, 72000);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.writeNbt(nbt, registries);
        nbt.putString("Script", script);
        nbt.putString("Mode", settings.mode().name());
        nbt.putBoolean("Redstone", settings.redstone());
        nbt.putInt("LinesPerTick", settings.linesPerTick());
        nbt.putInt("RepeatDelay", settings.repeatDelay());
        nbt.putBoolean("ShowOutput", settings.showOutput());
        nbt.putBoolean("LoopActive", loopActive);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.readNbt(nbt, registries);
        script = nbt.getString("Script");
        if (nbt.contains("Mode")) {
            Mode m;
            try { m = Mode.valueOf(nbt.getString("Mode")); }
            catch (IllegalArgumentException e) { m = Mode.IMPULSE; }
            settings = new Settings(m, nbt.getBoolean("Redstone"), nbt.getInt("LinesPerTick"),
                    nbt.getInt("RepeatDelay"), nbt.getBoolean("ShowOutput"));
        }
        loopActive = nbt.getBoolean("LoopActive");
    }
}
