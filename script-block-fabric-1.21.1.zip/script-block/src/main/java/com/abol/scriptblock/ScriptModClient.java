package com.abol.scriptblock;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class ScriptModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ScriptPayloads.OpenGui.ID, (payload, context) ->
                context.client().execute(() -> context.client().setScreen(new ScriptScreen(payload))));
    }
}
