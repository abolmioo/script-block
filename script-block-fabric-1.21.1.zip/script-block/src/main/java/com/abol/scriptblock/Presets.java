package com.abol.scriptblock;

import java.util.List;

public final class Presets {
    private Presets() {}

    public record Preset(String name, String script) {}

    public static final List<Preset> ALL = List.of(
        new Preset("SpongeBob", """
            # SpongeBob next to the block
            fill ~1 ~ ~2 ~7 ~11 ~5 air
            # Legs and shoes
            fill ~3 ~ ~3 ~3 ~1 ~3 yellow_concrete
            fill ~5 ~ ~3 ~5 ~1 ~3 yellow_concrete
            setblock ~3 ~ ~2 black_concrete
            setblock ~5 ~ ~2 black_concrete
            # Pants
            fill ~2 ~2 ~3 ~6 ~3 ~4 brown_concrete
            # Shirt and tie
            fill ~2 ~4 ~3 ~6 ~4 ~4 white_concrete
            setblock ~4 ~4 ~2 red_concrete
            # Body
            fill ~2 ~5 ~3 ~6 ~10 ~4 yellow_concrete
            # Sponge holes
            setblock ~6 ~9 ~4 lime_concrete
            setblock ~2 ~8 ~4 lime_concrete
            setblock ~6 ~6 ~3 lime_concrete
            setblock ~2 ~10 ~3 lime_concrete
            # Eyes
            fill ~3 ~7 ~3 ~3 ~8 ~3 white_concrete
            fill ~5 ~7 ~3 ~5 ~8 ~3 white_concrete
            setblock ~3 ~7 ~3 light_blue_concrete
            setblock ~5 ~7 ~3 light_blue_concrete
            # Nose
            setblock ~4 ~6 ~2 yellow_concrete
            # Smile and teeth
            setblock ~3 ~5 ~3 red_concrete
            setblock ~5 ~5 ~3 red_concrete
            setblock ~4 ~5 ~3 white_concrete
            # Arms
            fill ~1 ~5 ~3 ~1 ~7 ~3 yellow_concrete
            fill ~7 ~5 ~3 ~7 ~7 ~3 yellow_concrete
            setblock ~1 ~7 ~3 white_concrete
            setblock ~7 ~7 ~3 white_concrete
            wait 10
            summon firework_rocket ~4 ~12 ~3 {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"star",colors:[I;16776960]}]}}}}
            tellraw @a[distance=..50] {"text":"SpongeBob is ready!","color":"yellow"}
            """),
        new Preset("Small House", """
            # 7x7 house next to the block
            fill ~2 ~ ~2 ~8 ~7 ~8 air
            fill ~2 ~-1 ~2 ~8 ~-1 ~8 cobblestone
            fill ~2 ~ ~2 ~8 ~4 ~8 oak_planks hollow
            fill ~2 ~ ~2 ~2 ~4 ~2 oak_log
            fill ~8 ~ ~2 ~8 ~4 ~2 oak_log
            fill ~2 ~ ~8 ~2 ~4 ~8 oak_log
            fill ~8 ~ ~8 ~8 ~4 ~8 oak_log
            # Door
            setblock ~5 ~1 ~2 oak_door[half=lower,facing=north]
            setblock ~5 ~2 ~2 oak_door[half=upper,facing=north]
            # Windows
            setblock ~3 ~2 ~2 glass
            setblock ~7 ~2 ~2 glass
            setblock ~2 ~2 ~5 glass
            setblock ~8 ~2 ~5 glass
            setblock ~5 ~2 ~8 glass
            # Roof
            fill ~1 ~5 ~1 ~9 ~5 ~9 spruce_slab
            fill ~3 ~6 ~3 ~7 ~6 ~7 spruce_slab
            # Inside
            setblock ~5 ~3 ~5 lantern[hanging=true]
            setblock ~3 ~1 ~7 crafting_table
            setblock ~4 ~1 ~7 furnace
            setblock ~7 ~1 ~7 chest
            tellraw @a[distance=..50] {"text":"House built!","color":"green"}
            """),
        new Preset("Big Tree", """
            # Oak tree next to the block
            fill ~3 ~ ~3 ~3 ~6 ~3 oak_log
            fill ~1 ~4 ~1 ~5 ~5 ~5 oak_leaves[persistent=true] keep
            fill ~2 ~6 ~2 ~4 ~7 ~4 oak_leaves[persistent=true] keep
            setblock ~3 ~8 ~3 oak_leaves[persistent=true]
            """),
        new Preset("Firework Show", """
            # Fireworks above the block (try Repeat mode!)
            summon firework_rocket ~ ~2 ~ {LifeTime:30,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:2,explosions:[{shape:"large_ball",colors:[I;16711680]}]}}}}
            wait 10
            summon firework_rocket ~2 ~2 ~ {LifeTime:30,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:2,explosions:[{shape:"star",colors:[I;65280]}]}}}}
            wait 10
            summon firework_rocket ~-2 ~2 ~ {LifeTime:30,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:2,explosions:[{shape:"burst",colors:[I;255]}]}}}}
            wait 10
            summon firework_rocket ~ ~2 ~2 {LifeTime:30,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:2,explosions:[{shape:"creeper",colors:[I;16776960]}]}}}}
            """),
        new Preset("Heart Particles", """
            # Use Repeat + Always Active for a loop
            particle minecraft:heart ~ ~1.5 ~ 0.5 0.5 0.5 0 5
            particle minecraft:happy_villager ~ ~1 ~ 1 0.5 1 0 10
            """),
        new Preset("Perfect Day", """
            time set day
            weather clear
            gamerule doDaylightCycle false
            gamerule doWeatherCycle false
            effect give @a[distance=..30] night_vision 600 0 true
            tellraw @a {"text":"Perfect day activated","color":"aqua"}
            """),
        new Preset("Clear Area", """
            # Clears 21x15x21 above the block (be careful!)
            fill ~-10 ~1 ~-10 ~10 ~15 ~10 air
            kill @e[type=item,distance=..25]
            """)
    );
}
