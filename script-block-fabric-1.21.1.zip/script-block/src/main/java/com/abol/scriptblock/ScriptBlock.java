package com.abol.scriptblock;

import com.mojang.serialization.MapCodec;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class ScriptBlock extends BlockWithEntity {
    public static final MapCodec<ScriptBlock> CODEC = createCodec(ScriptBlock::new);

    public ScriptBlock(Settings settings) { super(settings); }

    @Override
    protected MapCodec<? extends BlockWithEntity> getCodec() { return CODEC; }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new ScriptBlockEntity(pos, state);
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) { return BlockRenderType.MODEL; }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        return world.isClient ? null : validateTicker(type, ScriptMod.SCRIPT_BLOCK_ENTITY, ScriptBlockEntity::tick);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient && player instanceof ServerPlayerEntity sp
                && world.getBlockEntity(pos) instanceof ScriptBlockEntity be) {
            if (!sp.hasPermissionLevel(2)) {
                sp.sendMessage(Text.literal("Only OPs can use Script Blocks").formatted(Formatting.RED), true);
                return ActionResult.FAIL;
            }
            ServerPlayNetworking.send(sp, new ScriptPayloads.OpenGui(pos, be.getScript(), be.getSettings(), be.isRunning()));
        }
        return ActionResult.SUCCESS;
    }
}
