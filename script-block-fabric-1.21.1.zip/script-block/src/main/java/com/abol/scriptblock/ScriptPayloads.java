package com.abol.scriptblock;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public final class ScriptPayloads {
    private ScriptPayloads() {}

    public enum Mode { IMPULSE, REPEAT }

    public enum Action { SAVE, RUN, STOP }

    public record Settings(Mode mode, boolean redstone, int linesPerTick, int repeatDelay, boolean showOutput) {
        public static final Settings DEFAULT = new Settings(Mode.IMPULSE, true, 10, 20, true);

        public Settings {
            if (mode == null) mode = Mode.IMPULSE;
            linesPerTick = MathHelper.clamp(linesPerTick, 1, 1000);
            repeatDelay = MathHelper.clamp(repeatDelay, 0, 72000);
        }

        public void write(PacketByteBuf buf) {
            buf.writeEnumConstant(mode);
            buf.writeBoolean(redstone);
            buf.writeVarInt(linesPerTick);
            buf.writeVarInt(repeatDelay);
            buf.writeBoolean(showOutput);
        }

        public static Settings read(PacketByteBuf buf) {
            return new Settings(buf.readEnumConstant(Mode.class), buf.readBoolean(),
                    buf.readVarInt(), buf.readVarInt(), buf.readBoolean());
        }
    }

    /** Server -> client: open the editor. */
    public record OpenGui(BlockPos pos, String script, Settings settings, boolean running) implements CustomPayload {
        public static final Id<OpenGui> ID = new Id<>(Identifier.of(ScriptMod.MOD_ID, "open_gui"));
        public static final PacketCodec<RegistryByteBuf, OpenGui> CODEC = PacketCodec.of(OpenGui::write, OpenGui::read);

        private void write(RegistryByteBuf buf) {
            buf.writeBlockPos(pos);
            buf.writeString(script, ScriptMod.MAX_LEN);
            settings.write(buf);
            buf.writeBoolean(running);
        }

        private static OpenGui read(RegistryByteBuf buf) {
            return new OpenGui(buf.readBlockPos(), buf.readString(ScriptMod.MAX_LEN), Settings.read(buf), buf.readBoolean());
        }

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Client -> server: save / run / stop. */
    public record SaveScript(BlockPos pos, String script, Settings settings, Action action) implements CustomPayload {
        public static final Id<SaveScript> ID = new Id<>(Identifier.of(ScriptMod.MOD_ID, "save_script"));
        public static final PacketCodec<RegistryByteBuf, SaveScript> CODEC = PacketCodec.of(SaveScript::write, SaveScript::read);

        private void write(RegistryByteBuf buf) {
            buf.writeBlockPos(pos);
            buf.writeString(script, ScriptMod.MAX_LEN);
            settings.write(buf);
            buf.writeEnumConstant(action);
        }

        private static SaveScript read(RegistryByteBuf buf) {
            return new SaveScript(buf.readBlockPos(), buf.readString(ScriptMod.MAX_LEN), Settings.read(buf), buf.readEnumConstant(Action.class));
        }

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }
}
