package com.abol.scriptblock;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ScriptMod implements ModInitializer {
    public static final String MOD_ID = "scriptblock";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Max chars for the network codec. */
    public static final int MAX_LEN = 32000;
    /** Max chars allowed in the editor. */
    public static final int EDITOR_LIMIT = 16000;
    /** Client->server packets must stay under ~32KB. */
    public static final int MAX_BYTES = 30000;

    public static final Block SCRIPT_BLOCK = new ScriptBlock(AbstractBlock.Settings.copy(Blocks.COMMAND_BLOCK));
    public static BlockEntityType<ScriptBlockEntity> SCRIPT_BLOCK_ENTITY;

    @Override
    public void onInitialize() {
        Identifier id = Identifier.of(MOD_ID, "script_block");
        Registry.register(Registries.BLOCK, id, SCRIPT_BLOCK);
        Item item = Registry.register(Registries.ITEM, id,
                new BlockItem(SCRIPT_BLOCK, new Item.Settings().rarity(Rarity.EPIC)));
        SCRIPT_BLOCK_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE, id,
                FabricBlockEntityTypeBuilder.create(ScriptBlockEntity::new, SCRIPT_BLOCK).build());

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(e -> e.add(item));

        PayloadTypeRegistry.playS2C().register(ScriptPayloads.OpenGui.ID, ScriptPayloads.OpenGui.CODEC);
        PayloadTypeRegistry.playC2S().register(ScriptPayloads.SaveScript.ID, ScriptPayloads.SaveScript.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ScriptPayloads.SaveScript.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            context.server().execute(() -> handleSave(player, payload));
        });

        LOGGER.info("Script Block loaded");
    }

    private static void handleSave(ServerPlayerEntity player, ScriptPayloads.SaveScript p) {
        if (!player.hasPermissionLevel(2)) {
            player.sendMessage(Text.literal("Only OPs can edit Script Blocks").formatted(Formatting.RED), true);
            return;
        }
        BlockPos pos = p.pos();
        if (player.squaredDistanceTo(Vec3d.ofCenter(pos)) > 64 * 64) return;
        if (!(player.getServerWorld().getBlockEntity(pos) instanceof ScriptBlockEntity be)) return;

        be.applySettings(p.script(), p.settings());
        switch (p.action()) {
            case RUN -> be.start(player);
            case STOP -> be.stop();
            case SAVE -> player.sendMessage(Text.literal("Script saved").formatted(Formatting.GREEN), true);
        }
    }
}
