package com.abol.scriptblock;

import com.abol.scriptblock.ScriptPayloads.Action;
import com.abol.scriptblock.ScriptPayloads.Mode;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.EditBoxWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.nio.charset.StandardCharsets;

public class ScriptScreen extends Screen {
    private static final int[] SPEEDS = {1, 5, 10, 50, 1000};
    private static final int[] DELAYS = {0, 5, 10, 20, 40, 100, 200};

    private final BlockPos pos;
    private final boolean running;
    private String text;
    private Mode mode;
    private boolean redstone;
    private boolean showOutput;
    private int speed;
    private int delay;
    private int presetIndex = 0;

    private EditBoxWidget box;
    private Text warning = Text.empty();
    private int left;
    private int rowW;

    public ScriptScreen(ScriptPayloads.OpenGui p) {
        super(Text.literal("Script Block"));
        this.pos = p.pos();
        this.running = p.running();
        this.text = p.script();
        this.mode = p.settings().mode();
        this.redstone = p.settings().redstone();
        this.speed = p.settings().linesPerTick();
        this.delay = p.settings().repeatDelay();
        this.showOutput = p.settings().showOutput();
    }

    @Override
    protected void init() {
        if (box != null) text = box.getText(); // keep text when window is resized

        int bw = 90, gap = 4;
        rowW = bw * 4 + gap * 3;
        left = (width - rowW) / 2;
        int top = 22;
        int bottom = height - 96;

        box = new EditBoxWidget(textRenderer, left, top, rowW, Math.max(40, bottom - top),
                Text.literal("One command per line. # = comment, wait 20 = pause 1s"), Text.literal("Script"));
        box.setMaxLength(ScriptMod.EDITOR_LIMIT);
        box.setText(text);
        addDrawableChild(box);
        setInitialFocus(box);

        int r1 = height - 78, r2 = height - 54, r3 = height - 30;
        int c0 = left, c1 = left + (bw + gap), c2 = left + 2 * (bw + gap), c3 = left + 3 * (bw + gap);

        // Row 1: settings
        addDrawableChild(button(modeLabel(), c0, r1, bw,
                "Impulse: runs once. Repeat: runs again and again.",
                b -> { mode = mode == Mode.IMPULSE ? Mode.REPEAT : Mode.IMPULSE; b.setMessage(modeLabel()); }));
        addDrawableChild(button(redstoneLabel(), c1, r1, bw,
                "Needs Redstone: a redstone signal triggers it. Always Active: Run button starts the loop.",
                b -> { redstone = !redstone; b.setMessage(redstoneLabel()); }));
        addDrawableChild(button(speedLabel(), c2, r1, bw,
                "How many commands run per game tick. Lower = less lag.",
                b -> { speed = next(SPEEDS, speed); b.setMessage(speedLabel()); }));
        addDrawableChild(button(delayLabel(), c3, r1, bw,
                "Ticks to wait between loops in Repeat mode (20 ticks = 1 second).",
                b -> { delay = next(DELAYS, delay); b.setMessage(delayLabel()); }));

        // Row 2: presets & tools
        addDrawableChild(button(presetLabel(), c0, r2, bw,
                "Click to pick a ready-made script.",
                b -> { presetIndex = (presetIndex + 1) % Presets.ALL.size(); b.setMessage(presetLabel()); }));
        addDrawableChild(button(Text.literal("Load Preset"), c1, r2, bw,
                "Replace the editor text with the selected preset.",
                b -> box.setText(Presets.ALL.get(presetIndex).script())));
        addDrawableChild(button(outputLabel(), c2, r2, bw,
                "Show a 'Done' message with error count when the script ends.",
                b -> { showOutput = !showOutput; b.setMessage(outputLabel()); }));
        addDrawableChild(button(Text.literal("Clear"), c3, r2, bw,
                "Delete all text.",
                b -> box.setText("")));

        // Row 3: actions
        addDrawableChild(button(Text.literal("▶ Run").formatted(Formatting.GREEN), c0, r3, bw,
                "Save and run the whole script.", b -> send(Action.RUN)));
        addDrawableChild(button(Text.literal("■ Stop").formatted(Formatting.RED), c1, r3, bw,
                "Stop a running script or loop.", b -> send(Action.STOP)));
        addDrawableChild(button(Text.literal("Save"), c2, r3, bw,
                "Save without running.", b -> send(Action.SAVE)));
        addDrawableChild(button(Text.literal("Cancel"), c3, r3, bw,
                "Close without saving.", b -> close()));
    }

    private ButtonWidget button(Text label, int x, int y, int w, String tip, ButtonWidget.PressAction action) {
        return ButtonWidget.builder(label, action)
                .dimensions(x, y, w, 20)
                .tooltip(Tooltip.of(Text.literal(tip)))
                .build();
    }

    private static int next(int[] values, int current) {
        for (int i = 0; i < values.length; i++) {
            if (values[i] == current) return values[(i + 1) % values.length];
        }
        return values[0];
    }

    private Text modeLabel() { return Text.literal(mode == Mode.IMPULSE ? "Mode: Impulse" : "Mode: Repeat"); }
    private Text redstoneLabel() { return Text.literal(redstone ? "Needs Redstone" : "Always Active"); }
    private Text speedLabel() { return Text.literal("Speed: " + (speed >= 1000 ? "All" : speed + "/t")); }
    private Text delayLabel() { return Text.literal("Delay: " + delay + "t"); }
    private Text presetLabel() { return Text.literal("» " + Presets.ALL.get(presetIndex).name()); }
    private Text outputLabel() { return Text.literal("Output: " + (showOutput ? "ON" : "OFF")); }

    private void send(Action action) {
        String script = box.getText();
        if (script.getBytes(StandardCharsets.UTF_8).length > ScriptMod.MAX_BYTES) {
            warning = Text.literal("Script too big!").formatted(Formatting.RED);
            return;
        }
        ScriptPayloads.Settings settings = new ScriptPayloads.Settings(mode, redstone, speed, delay, showOutput);
        ClientPlayNetworking.send(new ScriptPayloads.SaveScript(pos, script, settings, action));
        close();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 8, 0xFFFF55);

        String t = box.getText();
        int lines = t.isEmpty() ? 0 : t.split("\\R", -1).length;
        String status = "Lines: " + lines + "   Chars: " + t.length() + "/" + ScriptMod.EDITOR_LIMIT
                + "   " + (running ? "§aRunning" : "§7Idle");
        ctx.drawTextWithShadow(textRenderer, status, left, height - 92, 0xAAAAAA);
        if (!warning.getString().isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, warning, left + rowW - textRenderer.getWidth(warning), height - 92, 0xFFFFFF);
        }
    }

    @Override
    public boolean shouldPause() { return false; }
}
